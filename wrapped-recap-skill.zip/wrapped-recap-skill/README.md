# Wrapped recap: a Claude skill

Your year on Claude, as a tap-through, Wrapped-style story. Ask Claude to “make me a Wrapped” and it builds a page with one slide per month, your year in numbers, your top five themes, a playful personality title and, if you want one, an honest note.

![Light mode preview: intro, a month, the busiest month and the personality slide](docs/preview-light.png)
![Dark mode preview: year in numbers, top genres, an honest note and the outro](docs/preview-dark.png)

The example above is a fictional user. Open `docs/index.html` in a browser to click through it.

## What it does

- **Gathers** from Claude’s memory and past-chats search, month by month. If neither is available, it asks you for highlights. It never makes things up.
- **Sorts** each highlight into a month only when there’s a date or clear evidence. Undated things go on an “all year” slide.
- **Is honest about gaps.** Empty months become one “quiet season” slide, with consecutive empty months merged.
- **Keeps it shareable.** Health, money, relationships, surprises and other people’s private lives are left out, and Claude tells you what kinds of things it skipped.
- **Only counts what it can see.** Stats are evidenced totals, not estimates.
- **Works for any period:** a year, a summer, “since I started the job”.

The page is a single self-contained HTML file. It works on phones, follows light and dark mode, supports the keyboard (← → Home End) and respects reduced motion.

## Install

### Claude apps (claude.ai, desktop, mobile)

1. Download `wrapped-recap.zip` from the [latest release](../../releases/latest), or zip the `wrapped-recap/` folder yourself.
2. In Claude, open **Settings → Capabilities** and turn on **Code execution and file creation**.
3. Under **Skills**, choose **Upload skill** and pick the zip.

### Claude Code

Copy the `wrapped-recap/` folder into `~/.claude/skills/` (all projects) or `.claude/skills/` (one project):

```bash
git clone https://github.com/<your-username>/wrapped-recap-skill.git
cp -r wrapped-recap-skill/wrapped-recap ~/.claude/skills/
```

## Use it

Ask Claude something like:

- “Make me a Wrapped”
- “Recap my year on Claude”
- “What have I done this year?”
- “Monthly highlights of my chats since June”

It works best with **memory** and/or **past chats search** turned on in Claude’s settings.

## Repository layout

```
wrapped-recap/               the skill (this folder is what you upload)
├── SKILL.md                 instructions Claude follows
├── README.md
├── assets/
│   ├── template.html        page design, filled from one JSON object
│   └── example-data.json    fictional example year
└── scripts/
    ├── build.py             fills the template and checks the copy rules
    └── check_layout.mjs     checks every slide fits a 375×667 phone
docs/                        rendered example and preview images
.github/workflows/           checks on every push, zip on every release
```

## Develop

Requires Python 3.8+. The layout check also needs Node 18+ and Playwright.

```bash
python wrapped-recap/scripts/build.py wrapped-recap/assets/example-data.json docs/index.html
npm install --no-save playwright && npx playwright install chromium
node wrapped-recap/scripts/check_layout.mjs docs/index.html
```

To change the design, edit `wrapped-recap/assets/template.html`. To change what Claude writes, edit `wrapped-recap/SKILL.md`.

## Release

Push a tag starting with `v` and the release workflow attaches a ready-to-upload `wrapped-recap.zip`:

```bash
git tag v1.0.0
git push origin v1.0.0
```

## Licence

MIT. See [LICENSE](LICENSE).
